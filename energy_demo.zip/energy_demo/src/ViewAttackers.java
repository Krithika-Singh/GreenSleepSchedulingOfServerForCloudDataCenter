


import javax.swing.*;

import java.awt.event.*;
import java.sql.*;
import java.awt.*;
import java.io.*;
import java.util.*;

import javax.swing.JFrame;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.table.DefaultTableColumnModel;
import javax.swing.table.TableCellRenderer;
import javax.swing.table.TableColumn;

import java.awt.*;
import java.net.*;

public class ViewAttackers extends JFrame implements ActionListener
{
 JButton property,Reset;
 JPanel panel;
 JLabel label1;
  JTextField  text1;
  Vector data;
Vector heading;

JButton view;
JScrollPane pane;
JTable table;
int v,h;
String s,d,call,dt;
Container c;

JLabel imglabel;
ViewAttackers(Vector data) 
 {

setTitle("View Attackers :: GREEN SLEEP SCHEDULING OF SERVERS FOR CLOUD DATA CENTER");
c= getContentPane();
c.setLayout (null);
c.setBackground(new Color(179, 179, 255));

label1 = new JLabel();
label1.setText("Enter Username");

 text1 = new JTextField(20);
   property=new JButton("View Property");

   property.addActionListener(this);


//c.add(label1);
//c.add(text1);
//c.add(property);





try {

	 Vector heading = new Vector();
	 
	 
	 
//	 heading.addElement("SL NO");
		heading.addElement("Attacker");
		heading.addElement("File Name");
		heading.addElement("Secret Key Used");
		heading.addElement("Date");
	
	 
			  
			JTable table = new JTable(data,heading);
			  
			  pane = new JScrollPane(table);
			 
			  pane.setBounds(20,20,520,300);
			  c.add(pane);
			 // c.add(image);
	 
} 
	 catch(Exception ex) {
		 ex.printStackTrace();
		 } 

  }


public void actionPerformed(ActionEvent ae)
{

Object o=ae.getSource();

if(o==property)
{
		
}

}

}
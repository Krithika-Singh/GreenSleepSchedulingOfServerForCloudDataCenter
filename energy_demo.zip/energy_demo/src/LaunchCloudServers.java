/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author HOME
 */
public class LaunchCloudServers {
    public static void main(String[] args) {
        Cloudserver1 cs1 = new Cloudserver1();
        Cloudserver2 cs2 = new Cloudserver2();
        Cloudserver3 cs3 = new Cloudserver3();
    }
}
